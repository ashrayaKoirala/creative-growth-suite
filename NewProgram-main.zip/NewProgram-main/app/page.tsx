const Page = () => {
  return (
    <div>
      <h1>Welcome to Content Obsessed!</h1>
      <p>This is the dashboard page.</p>
    </div>
  )
}

export default Page
